/* CLIYRA — Theme behaviors
   Vanilla JS replacement for the original React component logic.
   Idempotent: safe to load defer once. */
(function () {
  'use strict';

  /* ── Klaviyo config ────────────────────────────────────── */
  var KLAVIYO_COMPANY_ID = 'RNsZBp';
  var KLAVIYO_LIST_ID    = 'YiTeQJ';
  /* ─────────────────────────────────────────────────────── */

  document.addEventListener('DOMContentLoaded', init);

  function init() {
    initScrollReveal();
    initStickyNav();
    initMobileMenu();
    initFAQ();
    initRemindModal();
    initRemindForm();
    initWaitlistForm();
  }

  /* ── Klaviyo subscribe helper ──────────────────────────── */
  function klaviyoSubscribe(email) {
    return fetch('https://a.klaviyo.com/client/subscriptions/?company_id=' + KLAVIYO_COMPANY_ID, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'revision': '2024-10-15'
      },
      body: JSON.stringify({
        data: {
          type: 'subscription',
          attributes: {
            profile: {
              data: {
                type: 'profile',
                attributes: {
                  email: email
                }
              }
            }
          },
          relationships: {
            list: {
              data: {
                type: 'list',
                id: KLAVIYO_LIST_ID
              }
            }
          }
        }
      })
    });
  }
  /* ─────────────────────────────────────────────────────── */

  /* Fade-in on scroll */
  function initScrollReveal() {
    var els = document.querySelectorAll('.reveal');
    if (!els.length) return;
    if (!('IntersectionObserver' in window)) {
      els.forEach(function (el) { el.classList.add('in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    els.forEach(function (el) { io.observe(el); });
  }

  /* Sticky nav becomes opaque after the user scrolls */
  function initStickyNav() {
    var nav = document.querySelector('[data-cliyra-nav]');
    if (!nav) return;
    function onScroll() {
      if (window.scrollY > 8) nav.classList.add('is-scrolled');
      else nav.classList.remove('is-scrolled');
    }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* Mobile hamburger menu */
  function initMobileMenu() {
    var toggle = document.querySelector('[data-cliyra-nav-toggle]');
    var menu = document.querySelector('[data-cliyra-mobile-menu]');
    if (!toggle || !menu) return;
    toggle.addEventListener('click', function () {
      menu.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', menu.classList.contains('is-open') ? 'true' : 'false');
    });
    menu.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { menu.classList.remove('is-open'); });
    });
  }

  /* FAQ accordion — single-open behavior, click open one closes others */
  function initFAQ() {
    var items = document.querySelectorAll('[data-cliyra-faq-item]');
    if (!items.length) return;
    items.forEach(function (item) {
      var btn = item.querySelector('button');
      if (!btn) return;
      btn.addEventListener('click', function () {
        var alreadyOpen = item.classList.contains('is-open');
        items.forEach(function (other) { other.classList.remove('is-open'); });
        if (!alreadyOpen) item.classList.add('is-open');
        btn.setAttribute('aria-expanded', !alreadyOpen ? 'true' : 'false');
      });
    });
    if (items[0]) items[0].classList.add('is-open');
  }

  /* Remind-me modal: open from desktop hover button + mobile fallback,
     close with backdrop click, X, or Escape. Locks body scroll while open. */
  function initRemindModal() {
    var modal = document.querySelector('[data-cliyra-modal]');
    if (!modal) return;
    var openers = document.querySelectorAll('[data-cliyra-modal-open]');
    var closers = modal.querySelectorAll('[data-cliyra-modal-close]');

    function open() {
      modal.classList.add('is-open');
      modal.classList.remove('is-success');
      modal.classList.remove('is-error');
      document.body.style.overflow = 'hidden';
      var input = modal.querySelector('input[type="email"]');
      if (input) {
        input.value = '';
        setTimeout(function () { input.focus(); }, 80);
      }
    }
    function close() {
      modal.classList.remove('is-open');
      document.body.style.overflow = '';
    }
    openers.forEach(function (o) { o.addEventListener('click', open); });
    closers.forEach(function (c) { c.addEventListener('click', close); });
    modal.addEventListener('click', function (e) {
      if (e.target === modal) close();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modal.classList.contains('is-open')) close();
    });
  }

  /* Modal back-in-stock form → Klaviyo subscribe */
  function initRemindForm() {
    var form = document.querySelector('[data-cliyra-remind-form]');
    var modal = document.querySelector('[data-cliyra-modal]');
    if (!form || !modal) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var input = form.querySelector('input[type="email"]');
      if (!input || !input.value) return;
      var btn = form.querySelector('button[type="submit"]');
      if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }

      klaviyoSubscribe(input.value.trim())
        .then(function (res) {
          if (res.ok || res.status === 202) {
            modal.classList.add('is-success');
          } else {
            console.error('Klaviyo remind error:', res.status);
            modal.classList.add('is-error');
          }
        })
        .catch(function (err) {
          console.error('Klaviyo remind error:', err);
          modal.classList.add('is-error');
        })
        .finally(function () {
          if (btn) { btn.disabled = false; btn.textContent = 'Remind Me'; }
        });
    });
  }

  /* Waitlist section form → Klaviyo subscribe */
  function initWaitlistForm() {
    var form = document.querySelector('[data-cliyra-waitlist-form]');
    var section = document.querySelector('[data-cliyra-waitlist]');
    if (!form || !section) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var input = form.querySelector('input[type="email"]');
      if (!input || !input.value) return;
      var btn = form.querySelector('button[type="submit"]');
      if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }

      klaviyoSubscribe(input.value.trim())
        .then(function (res) {
          if (res.ok || res.status === 202) {
            section.classList.add('is-success');
          } else {
            console.error('Klaviyo waitlist error:', res.status);
            section.classList.add('is-error');
          }
        })
        .catch(function (err) {
          console.error('Klaviyo waitlist error:', err);
          section.classList.add('is-error');
        })
        .finally(function () {
          if (btn) { btn.disabled = false; btn.textContent = 'Notify Me'; }
        });
    });
  }
})();